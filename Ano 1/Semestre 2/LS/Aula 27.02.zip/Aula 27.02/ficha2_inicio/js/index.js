"use strict";

var panelControl = document.getElementById('panel-control');
var panelGame = document.getElementById('game');
var btLevel = document.getElementById('btLevel');
var btPlay = document.getElementById('btPlay');
var message = document.getElementById('message');
const listItens = document.querySelectorAll('.list-item');

function reset()
{
    panelGame.style.display = 'none';
    message.textContent = ' ';
    message.classList.remove('hide');
    btPlay.disabled = 'false';
    btLevel.value = '0'
    listItens.forEach(function(elemento){elemento.classList.remove('gameStarted')});
}

function SelectLevel() //Pode incluir na função Reset
{
    if(btLevel.value === '0')
        btPlay.disabled = true;
    else
        btPlay.disabled = false;
        panelGame.style.display = 'grid';
}

function StartGame()
{

    btPlay.textContent = "Terminar Jogo";
    btLevel.disabled = true;
    message.classList.add('hide');
    listItens.forEach(function(elemento){elemento.classList.add('gameStarted')});

    /*if(btPlay.textContent === "Iniciar Jogo")
    {
        btPlay.textContent = "Terminar Jogo";
        btLevel.disabled = true;
        message.classList.add('hide');
        listItens.forEach(function(elemento){elemento.classList.add('gameStarted')});
    }
    else //Substitui a função stopGame
    {
        /*btPlay.textContent = "Iniciar Jogo";
        btLevel.disabled = false;
        btLevel.value = '0'
        message.classList.remove('hide');
        listItens.forEach(function(elemento){elemento.classList.remove('gameStarted')}); //Pode adicionar no reset
    }*/

}

function StopGame()
{
    btPlay.textContent = "Iniciar Jogo";
    btLevel.disabled = false;
    reset();
}

reset();
btLevel.addEventListener('change' , SelectLevel);
btPlay.addEventListener('click', function(){

    if(btPlay.textContent === "Terminar Jogo")
    {
        StopGame();
    }
    else
    {
        StartGame();
    }
});

panelControl.addEventListener('click', function(){
    message.textContent === '' ? message.textContent = 'Clique em Iniciar o Jogo!' : message.textContent = ''
});

